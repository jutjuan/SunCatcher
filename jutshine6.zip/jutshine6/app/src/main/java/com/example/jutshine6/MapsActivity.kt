package com.example.jutshine6

import org.json.JSONObject
import kotlin.math.round
import java.math.BigDecimal
import java.math.RoundingMode
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.*
import com.android.volley.Request
import com.android.volley.Response
import com.android.volley.toolbox.StringRequest
import com.android.volley.toolbox.Volley

import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.OnMapReadyCallback
import com.google.android.gms.maps.SupportMapFragment
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.MarkerOptions
import com.example.jutshine6.databinding.ActivityMapsBinding
import com.google.android.gms.maps.model.Marker
//import khttp.delete as httpDelete
import androidx.appcompat.app.ActionBar
import com.android.volley.toolbox.JsonObjectRequest
import com.android.volley.toolbox.JsonRequest
import com.google.android.material.floatingactionbutton.FloatingActionButton
import okhttp3.OkHttpClient

import java.text.SimpleDateFormat
import java.util.*

class MapsActivity : AppCompatActivity(), OnMapReadyCallback{

    var YEARLY_HOUSE_CONSUMPTION: Float = 10000f
    var efficiencyOnPoint: Float = 5f
    var sunTime:String = ""
    val solarCellEfficiency:Float = 0.15f

    private val client = OkHttpClient()
    private lateinit var mMap: GoogleMap
    private lateinit var binding: ActivityMapsBinding
    var texto_edit = ""


    override fun onCreate(savedInstanceState: Bundle?) {

        super.onCreate(savedInstanceState)

        binding = ActivityMapsBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val numberInput: EditText = findViewById<View>(R.id.numberInput) as EditText
        texto_edit = numberInput.text.toString()

        var supportActionBar:ActionBar
        supportActionBar = getSupportActionBar() as ActionBar
        supportActionBar.hide()

        val mapFragment = supportFragmentManager
            .findFragmentById(R.id.map) as SupportMapFragment
        mapFragment.getMapAsync(this)

        val botonUbi: FloatingActionButton = findViewById(R.id.ubi)

        botonUbi.setOnClickListener() {
            val text = "I swear this worked before!"
            val duration = Toast.LENGTH_SHORT

            val toast = Toast.makeText(applicationContext, text, duration)
            toast.show()
        }

    }


    override fun onMapReady(googleMap: GoogleMap) {
        val mostrar_coordenadas: TextView = findViewById(R.id.coords)

        mMap = googleMap

        var punto = LatLng(50.0, 50.0)
        var miMarcador: Marker = mMap.addMarker(MarkerOptions().position(punto as LatLng))
        mMap.moveCamera(CameraUpdateFactory.newLatLng(punto))


        val mapClickListener = object : GoogleMap.OnMapClickListener {
            override fun onMapClick(punto: LatLng?) {
                Log.d("Map_Tag", "CLICK")
                miMarcador.position = punto as LatLng
                mostrar_coordenadas.text = punto.toString()

                EfRequest(punto.latitude.toFloat(), punto.longitude.toFloat())
                StRequest(punto.latitude.toFloat(), punto.longitude.toFloat())

                showData()


            }
        }

        val calculateButton = findViewById<View>(R.id.calculate) as Button
        calculateButton.setOnClickListener(View.OnClickListener { Calculate() })

        mMap.setOnMapClickListener(mapClickListener) //Note. Use () and not {}


    }

    fun EfRequest(latitude:Float, longitude:Float){

        val sdf = SimpleDateFormat("yyyyMM")
        var dateString = sdf.format(Date()).toString()
        dateString += "01"
        val date = dateString.toInt()
        val yearBefore = date-10000
        var oneMonth = yearBefore + 27


        var base_url: String = "https://power.larc.nasa.gov/api/temporal/daily/point?parameters=CLRSKY_SFC_SW_DWN&community=RE&longitude={longitude}&latitude={latitude}&start={xxxxxxxx}&end={yyyyyyyy}&format=JSON"
        var newUrl = base_url.replace("{longitude}", longitude.toString()).replace("{latitude}",latitude.toString()).replace("{xxxxxxxx}", yearBefore.toString()).replace("{yyyyyyyy}", oneMonth.toString())
        System.out.println(newUrl)
        // ...

        // Instantiate the RequestQueue.
        val queue = Volley.newRequestQueue(this)

        // Request a string response from the provided URL.
        val stringRequest = JsonObjectRequest(Request.Method.GET, newUrl, null,
            Response.Listener<JSONObject> { response ->
                // Display the first 500 characters of the response string.
                //textView.text = "Response is: ${response.substring(0, 500)}"
                var index:Int = 0
                var json_clrsky = response.getJSONObject("properties").getJSONObject("parameter").getString("CLRSKY_SFC_SW_DWN")

                var string_clrsky = json_clrsky.replace("{", "").replace("}", "").replace("\"", "")
                var vector_clrsky = string_clrsky.split(",")

                var sum = 0.0
                for(i: String in vector_clrsky) {
                    var j = i.split(":")
                    sum += j[1].toFloat()
                }
                efficiencyOnPoint = (sum / 28f).toFloat()


            },
            Response.ErrorListener {val text = "Error!"
                val duration = Toast.LENGTH_SHORT

                val toast = Toast.makeText(applicationContext, text, duration)
                toast.show()})



        // Add the request to the RequestQueue.
        queue.add(stringRequest)


    }

    fun StRequest(latitude:Float, longitude:Float){

        var base_url: String = "https://api.sunrise-sunset.org/json?lat={latitude}&lng={longitude}&date=today"
        var newUrl = base_url.replace("{longitude}", longitude.toString()).replace("{latitude}",latitude.toString())
        System.out.println(newUrl)

        val queue = Volley.newRequestQueue(this)

        val stringRequest = JsonObjectRequest(Request.Method.GET, newUrl, null,
            Response.Listener<JSONObject> { response ->
                // Display the first 500 characters of the response string.
                //textView.text = "Response is: ${response.substring(0, 500)}"
                var index:Int = 0
                var json_st = response.getJSONObject("results").getString("day_length")
                System.out.println(json_st)
                var string_st = json_st.replace("\"", "")
                var vector_st = string_st.split(":")
                string_st = vector_st[0] + ":" + vector_st[1]

                sunTime = string_st

            },
            Response.ErrorListener {val text = "Error!"
                val duration = Toast.LENGTH_SHORT

                val toast = Toast.makeText(applicationContext, text, duration)
                toast.show() })



        // Add the request to the RequestQueue.
        queue.add(stringRequest)


    }

    fun showData(){
        //Cantidad de sol
        val sunTimeText = findViewById<View>(R.id.sunTimeText) as TextView //Necesita que el texto se llame sunTimeText
        sunTimeText.setText(sunTime + " hours of sun")

        //sqrM para una casa
        var needed : Float = ((YEARLY_HOUSE_CONSUMPTION/ 365) / (efficiencyOnPoint * efficiencyOnPoint))
        val neededText = findViewById<View>(R.id.neededText) as TextView //Necesita que el texto se llame sunTimeText
        neededText.setText(needed.toDouble().round(2).toString()+" m2 of solar cells")

        //ammount of sun
        var fill = findViewById<View>(R.id.ammountOfSun) as ProgressBar
        var fillAmmount:Float = efficiencyOnPoint*10
        if(fillAmmount >= 100){
            fillAmmount = 100f
        }
        fill.progress = fillAmmount.toInt()
    }

    fun EnergyGeneratedaDay (kwhm2day: Float, m2: Float) : Float {
        return kwhm2day * m2 * solarCellEfficiency
    }

    fun anualSave (EnergyGeneratedaDay: Float, USDperkwh: Float) : Float {
        return EnergyGeneratedaDay * USDperkwh * 365
    }

    fun Calculate(){
        //Get square meters from input text
        val numberInput: EditText = findViewById<View>(R.id.numberInput) as EditText
        var sqrMeters: Float = 1f

        if(!numberInput.text.toString().equals(texto_edit)) {
            sqrMeters = numberInput.text.toString().toFloat()
            //Calculate energy produced
            var energy: Float = EnergyGeneratedaDay(efficiencyOnPoint, sqrMeters)
            val energyText = findViewById<View>(R.id.energyText) as TextView //Necesita que el texto se llame sunTimeText
            energyText.setText(energy.toDouble().round(2).toString() + " Kw/h")

            //Calculate money saved
            var saved: Float = anualSave(energy, 0.1739f);
            val savedText = findViewById<View>(R.id.savedText) as TextView
            savedText.setText(saved.toDouble().round(2).toString() + " €")
        } else {
            val text = "Introduce a number of cells!"
            val duration = Toast.LENGTH_SHORT

            val toast = Toast.makeText(applicationContext, text, duration)
            toast.show()
        }


    }
    fun Double.round(decimals: Int): Double {
        var multiplier = 1.0
        repeat(decimals) { multiplier *= 10 }
        return round(this * multiplier) / multiplier
    }

}

